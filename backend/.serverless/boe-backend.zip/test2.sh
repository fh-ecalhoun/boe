curl -X POST https://8do415ddng.execute-api.us-east-1.amazonaws.com/intent \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello from BOE"}'

